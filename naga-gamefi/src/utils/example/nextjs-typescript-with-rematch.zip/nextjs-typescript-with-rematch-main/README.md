# nextjs-typescript-with-rematch

Boilerplate Application for next.js + TypeScript + rematch(redux)

Example codes are based on react State Hook

Codes are derived from:

- [zeit/next/examples/with-typescript](https://github.com/zeit/next.js/tree/master/examples/with-typescript)
- [zeit/next/examples/with-rematch](https://github.com/zeit/next.js/tree/master/examples/with-rematch)
- [rematch/rematch/examples/ts/hooks](https://github.com/rematch/rematch/tree/master/examples/ts/hooks)
