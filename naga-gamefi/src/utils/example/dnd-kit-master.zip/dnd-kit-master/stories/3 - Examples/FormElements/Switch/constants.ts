export enum State {
  On = 'on',
  Off = 'off',
}
