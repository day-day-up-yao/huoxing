export {removeIcon} from './remove';
