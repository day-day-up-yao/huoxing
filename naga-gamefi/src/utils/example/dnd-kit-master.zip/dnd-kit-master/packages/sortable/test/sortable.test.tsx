describe('@dnd-kit/sortable', () => {
  it('works', () => {
    expect(true).toBe(true);
  });
});

export {};
