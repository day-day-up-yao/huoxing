export interface Disabled {
  draggable?: boolean;
  droppable?: boolean;
}
