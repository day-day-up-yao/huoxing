describe('@dnd-kit/utilities', () => {
  it('works', () => {
    expect(true).toBe(true);
  });
});

export {};
