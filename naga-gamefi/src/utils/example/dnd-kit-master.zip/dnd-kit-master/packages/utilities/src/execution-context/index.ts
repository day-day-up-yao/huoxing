export {canUseDOM} from './canUseDOM';
export {getOwnerDocument} from './getOwnerDocument';
export {getWindow} from './getWindow';
