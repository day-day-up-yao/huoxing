# @dnd-kit/utilities

[![Stable release](https://img.shields.io/npm/v/@dnd-kit/utilities.svg)](https://npm.im/@dnd-kit/sortable)

Internal utilities to bee shared between `@dnd-kit` packages.
