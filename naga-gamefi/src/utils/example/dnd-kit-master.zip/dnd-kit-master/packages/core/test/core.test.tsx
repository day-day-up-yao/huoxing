describe('@dnd-kit/core', () => {
  it('works', () => {
    expect(true).toBe(true);
  });
});

export {};
