export {TouchSensor} from './TouchSensor';
export type {TouchSensorOptions, TouchSensorProps} from './TouchSensor';
