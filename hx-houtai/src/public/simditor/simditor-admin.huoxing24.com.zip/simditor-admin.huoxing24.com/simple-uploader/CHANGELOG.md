
## V3.0.0 - 2016-08-02

* Upgrade dependencies to simple-module 3.0 and jQuery 3.1.
* Cancle uploading will remove corresponding file in files array.

## Older Versions

Change logs under V3.0.0 are not recorded here, please check [Release History](https://github.com/mycolorway/simple-module/releases).
