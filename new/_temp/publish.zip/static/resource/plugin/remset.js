(function (doc, win) {
    var docEl = doc.documentElement;
    var resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize';
    var recalc = function () {
        var clientWidth = docEl.clientWidth;
        if (!clientWidth) return;

        if (clientWidth > 480) clientWidth = 480
        docEl.style.fontSize = (clientWidth * 24 / 640).toFixed(5) + 'px'; // (最小字体12px,最小宽度320,设计图当前宽度640=>计算出24)
    };
    recalc();
    if (!doc.addEventListener) return;
    win.addEventListener(resizeEvt, recalc, false);
    doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);
